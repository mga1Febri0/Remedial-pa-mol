<div class="card">
   <div class="card-body">
   <?php 
include 'koneksi.php';
?>
<div class="row">
<div class="col-md-12">
   <h1>Kategori Buku</h1>
      <a href="kategori_tambah.php" class="btn btn-primary">Tambah Data</a>
   </div>
   <br>
   <!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  
   <div class="card-body">
      <div class="table-responsive">
         <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
               <tr>
                  <th>No</th>
                  <th>Nama Kategori</th>
                  <th>Aksi</th>
               </tr>
            </thead>
            <tbody>
               <?php
               $i = 1;
               // Query SQL yang diperbaiki
               $query = mysqli_query($koneksi, "SELECT * FROM `kategoribuku`");

               while ($data = mysqli_fetch_array($query)) {
               ?>
                  <tr>
                     <td><?php echo $i++; ?></td>
                     <td><?php echo $data['NamaKategori']; // Sesuaikan nama kolom ?></td>
                     <td>

                     <a href="kategori_ubah.php?id=<?php echo $data['KategoriID']; ?>" class="btn btn-primary" onclick="return confirm('Yakin ingin mengubah data ini?')">Ubah</a>
                        <a href="kategori_hapus.php?id=<?php echo $data['KategoriID']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>

                     </td>
                  </tr>
               <?php
               }
               ?>

               
            </tbody>
         </table>
      </div>
   </div>
</div>

   </div>
</div>