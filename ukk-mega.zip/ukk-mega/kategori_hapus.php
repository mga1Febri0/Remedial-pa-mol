<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Menggunakan prepared statement untuk menghindari SQL injection
    $stmt = $koneksi->prepare("DELETE FROM kategoribuku WHERE KategoriID = ?");
    $stmt->bind_param("i", $id); // "i" menunjukkan tipe data integer
    $stmt->execute();

    // Cek apakah penghapusan berhasil
    if ($stmt->affected_rows > 0) {
        echo "<script>
            alert('Hapus data berhasil');
            location.href = 'index.php?page=kategorii'; // Redirect setelah berhasil
        </script>";
    } else {
        echo "<script>
            alert('Hapus data gagal');
            location.href = 'index.php?page=kategorii'; // Redirect jika gagal
        </script>";
    }

    $stmt->close();
} else {
    echo "<script>
        alert('ID tidak ditemukan');
        location.href = 'index.php?page=kategorii'; // Redirect jika tidak ada ID yang diberikan
    </script>";
}
?>
