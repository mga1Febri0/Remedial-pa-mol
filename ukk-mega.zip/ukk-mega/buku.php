<div class="card">
   <div class="card-body">
      <?php 
      include 'koneksi.php';
      ?>
      <div class="row">
         <div class="col-md-12">
            <h1>Buku</h1>
            <a href="buku_tambah.php" class="btn btn-primary">Tambah Data</a>
         </div>
      </div>
      <br>
      <!-- Bootstrap 5 CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

      <div class="card-body">
         <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                     <th>No</th>
                     <th>Nama Kategori</th>
                     <th>Judul</th>
                     <th>Penulis</th>
                     <th>Penerbit</th>
                     <th>Tahun Terbit</th>
                     <th>Aksi</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                  $i = 1;
                  // Query SQL untuk mengambil data buku beserta nama kategori
                  $query = mysqli_query($koneksi, "SELECT * FROM `buku` JOIN .kategoribuku=`NamaKategori`");
                  

                  while ($data = mysqli_fetch_array($query))

                  while ($data = mysqli_fetch_array($query)) {
                  ?>
                     <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $data['NamaKategori']; ?></td>
                        <td><?php echo $data['Judul']; ?></td>
                        <td><?php echo $data['Penulis']; ?></td>
                     
                      <td>  <?php echo $data['Penerbit']; ?></td>
                       <td> <?php echo $data['TahunTerbit']; ?></td>
                        <td>
                        <a href="buku_ubah.php?Buku_ID=<?php echo $data['KategoriID']; ?>" class="btn btn-primary" onclick="return confirm('Yakin ingin mengubah data ini?')">Ubah</a>
                        <a href="Buku_hapus.php?ID=<?php echo $data['KategoriID']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                     </tr>
                  <?php
                  }
                  ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div>
