<?php 
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ulasan Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <h1 class="mt-4">Buku</h1>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <form method="post">
                        <?php
                        if (isset($_POST['submit'])) {
                            $buku_id = $_POST['buku_id'];
                            $user_id = $_SESSION ['user']['user_id'];
                            $ulasan = $_POST['ulasan_id'];
                            $rating= $_POST['rating'];
                            
                            
                            // Ambil nilai kategori dari form
                            $kategori = $_POST['kategori'];

                            // Query untuk memasukkan data baru
                            $query = mysqli_query($koneksi, "INSERT INTO ulasan(buku_id,user_id,ulasan,rating) values('$buku_id','$user_id','$ulasan','$rating')");

                            if ($query) {
                                echo '<script>
                                    alert("Tambah data berhasil.");
                                    window.location.href = "http://localhost/ukk-ririn/kategorii.php"; // Redirect ke halaman kategori
                                </script>';
                            } else {
                                echo '<script>alert("Tambah data gagal.");</script>';
                            }
                        }
                        ?>
                        <div class="row mb-3">
                            <div class="col-md-2">Buku</div>
                            <div class="col-md-8">
                                <select name="buku_id" class="form-select">
                                    <option value="" disabled selected>Pilih Kategori</option>
                                    <?php
                                    $buk = mysqli_query($koneksi, "SELECT * FROM `buku`");
                                    while ($kategori = mysqli_fetch_array($buk)) {
                                        echo '<option value="' . $kategori['BukuID'] . '">' . $kategori['judul'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        

                        <div class="row mb-3">
                            <div class="col-md-2">Ulasan</div>
                            <div class="col-md-9">
                                <input type="number" class="form-control" name="Ulasan" required>
                            </div>

                            <div class="row mb-3">
                            <div class="col-md-2">Rating</div>
                            <div class="col-md-8">
                                <select name="rating" class="from-control">
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <a href="http://localhost/ukk-ririn/buku_tambah.php" class="btn btn-danger">Kembali</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
