<?php
include 'koneksi.php';

// Periksa apakah parameter ID ada
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Pastikan parameter ID valid (bernilai angka dan tidak kosong)
    if (!empty($id) && is_numeric($id)) {
        // Menggunakan prepared statement untuk menghindari SQL injection
        $stmt = $koneksi->prepare("DELETE FROM buku WHERE Buku_ID = ?");
        if ($stmt) {
            $stmt->bind_param("i", $id); // "i" menunjukkan tipe data integer
            $stmt->execute();

            // Cek apakah penghapusan berhasil
            if ($stmt->affected_rows > 0) {
                echo "<script>
                    alert('Hapus data berhasil');
                    location.href = 'index.php?page=kategorii'; // Redirect setelah berhasil
                </script>";
            } else {
                echo "<script>
                    alert('Hapus data gagal atau data tidak ditemukan');
                    location.href = 'index.php?page=kategorii'; // Redirect jika gagal
                </script>";
            }
            $stmt->close();
        } else {
            echo "<script>
                alert('Terjadi kesalahan pada query');
                location.href = 'index.php?page=kategorii'; // Redirect jika terjadi error pada prepared statement
            </script>";
        }
    } else {
        // id tidak valid
    if ($stmt->affected_rows > 0) {
        echo "<script>
            alert('Hapus data berhasil');
            location.href = 'index.php?page=kategorii'; // Redirect setelah berhasil
        </script>";
    } else {
        echo "<script>
            alert('Hapus data gagal');
            location.href = 'index.php?page=kategorii'; // Redirect jika gagal
        </script>";
    }
    }
} else {
    // Parameter ID tidak ditemukan
    echo "<script>
        alert('Berhasil di hapus');
        location.href = 'index.php?page=kategorii'; // Redirect jika tidak ada parameter ID
    </script>";
}
?>
