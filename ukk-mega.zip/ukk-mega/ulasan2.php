<div class="card">
    <div class="card-body">
        <?php 
        include 'koneksi.php';
        ?>
        <div class="row">
            <div class="col-md-12">
                <h1>Ulasan Buku</h1>
                <a href="ulasan_tambah.php" class="btn btn-primary">Tambah Data</a>
            </div>
        </div>
        <br>
        <!-- Bootstrap 5 CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>User</th>
                            <th>Buku</th>
                            <th>Ulasan</th>
                            <th>Rating</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;

                    
                        $query = mysqli_query($koneksi, "
                            SELECT 
                                ulasan.Ulasan_ID, 
                                user.Nama AS User_Nama, 
                                buku.Judul AS Buku_Judul, 
                                ulasan.Ulasan, 
                                ulasan.Rating
                            FROM 
                                ulasan
                            LEFT JOIN 
                                user ON user.User_ID = ulasan.User_ID
                            LEFT JOIN 
                                buku ON buku.Buku_ID = ulasan.Buku_ID
                        ");

                        // Periksa apakah query berhasil dijalankan
                        if ($query) {
                            while ($data = mysqli_fetch_array($query)) {
                        ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo htmlspecialchars($data['User_Nama']); // Mencegah XSS ?></td>
                                    <td><?php echo htmlspecialchars($data['Buku_Judul']); ?></td>
                                    <td><?php echo htmlspecialchars($data['Ulasan']); ?></td>
                                    <td><?php echo htmlspecialchars($data['Rating']); ?></td>
                                    <td>
                                        <a href="ulasan_ubah.php?id=<?php echo $data['Ulasan_ID']; ?>" class="btn btn-primary" onclick="return confirm('Yakin ingin mengubah data ini?')">Ubah</a>
                                        <a href="ulasan_hapus.php?id=<?php echo $data['Ulasan_ID']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        } else {
                            // Jika query gagal, tampilkan pesan error
                            echo "<tr><td colspan='6'>Terjadi kesalahan pada query: " . mysqli_error($koneksi) . "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
