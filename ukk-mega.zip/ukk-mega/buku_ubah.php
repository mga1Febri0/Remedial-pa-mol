<?php 
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Update Buku</h1>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <form method="post">
                            <?php
                            if (isset($_GET['Buku_ID'])) {
                                $id = $_GET['Buku_ID'];
                                // Ambil data buku berdasarkan ID
                                $query = mysqli_query($koneksi, "SELECT * FROM buku WHERE Buku_ID = '$id'");
                                $data = mysqli_fetch_array($query);
                                if (!$data) {
                                    echo '<script>alert("Data Buku tidak ditemukan."); window.location.href = "buku_tambah.php";</script>';
                                    exit;
                                }
                            } else {
                                echo '<script>alert("ID Buku tidak ditemukan."); window.location.href = "buku_tambah.php";</script>';
                                exit;
                            }

                            if (isset($_POST['submit'])) {
                                $id_kategori = $_POST['kategori'];
                                $judul = $_POST['judul'];
                                $penulis = $_POST['Penulis'];
                                $penerbit = $_POST['Penerbit'];
                                $tahun_terbit = $_POST['TahunTerbit'];
                            
                                // Update data buku
                                $updateQuery = mysqli_query($koneksi, 
                                    "UPDATE buku SET 
                                        Judul = '$judul', 
                                        Penulis = '$penulis', 
                                        Penerbit = '$penerbit', 
                                        TahunTerbit = '$tahun_terbit', 
                                        Kategori_ID = '$id_kategori' 
                                    WHERE Buku_ID = '$id'"
                                );

                                if ($updateQuery) {
                                    echo '<script>
                                        alert("Data berhasil diubah.");
                                        window.location.href = "kategorii.php";
                                    </script>';
                                } else {
                                    echo '<script>alert("Data gagal diubah.");</script>';
                                }
                            }
                            ?>
                            <div class="row mb-3">
                                <div class="col-md-2">Kategori</div>
                                <div class="col-md-8">
                                    <select name="kategori" class="form-select" required>
                                        <option value="" disabled selected>Pilih Kategori</option>
                                        <?php
                                        $kat = mysqli_query($koneksi, "SELECT * FROM `kategoribuku`");
                                        while ($kategoribuku = mysqli_fetch_array($kat)) {
                                            $selected = ($kategoribuku['Kategori_ID'] == $data['Kategori_ID']) ? 'selected' : '';
                                            echo "<option value='{$kategoribuku['Kategori_ID']}' $selected>{$kategoribuku['NamaKategori']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-2">Judul</div>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo htmlspecialchars($data['Judul']); ?>" class="form-control" name="judul" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-2">Penulis</div>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo htmlspecialchars($data['Penulis']); ?>" class="form-control" name="Penulis" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-2">Penerbit</div>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo htmlspecialchars($data['Penerbit']); ?>" class="form-control" name="Penerbit" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-2">Tahun Terbit</div>
                                <div class="col-md-8">
                                    <input type="number" value="<?php echo htmlspecialchars($data['TahunTerbit']); ?>" class="form-control" name="TahunTerbit" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-8">
                                    <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                                    <button type="reset" class="btn btn-secondary">Reset</button>
                                    <a href="buku_tambah.php" class="btn btn-danger">Kembali</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
