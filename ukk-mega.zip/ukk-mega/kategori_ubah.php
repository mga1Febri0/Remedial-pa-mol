<?php 
include 'koneksi.php';
?>

<h1 class="mt-4">Ubah Kategori Buku</h1>
<div class="card">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <form method="post">
                    <?php
                    // Pastikan ada ID yang dikirimkan melalui URL
                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                        $id = $_GET['id'];

                        // Jika form disubmit
                        if (isset($_POST['submit'])) {
                            $kategoribuku = $_POST['kategoribuku'];

                            // Proses Update Data
                            $query = mysqli_query($koneksi, "UPDATE kategoribuku SET NamaKategori='$kategoribuku' WHERE KategoriID=$id");

                            if ($query) {
                                echo '<script>
                                    alert("Ubah data berhasil.");
                                    window.location.href = "index.php?page=kategorii"; // Redirect ke halaman kategori
                                </script>';
                            } else {
                                echo '<script>alert("Ubah data gagal.");</script>';
                            }
                        }

                        // Mengambil data kategori berdasarkan ID
                        $query = mysqli_query($koneksi, "SELECT * FROM kategoribuku WHERE KategoriID=$id");
                        if (mysqli_num_rows($query) > 0) {
                            $data = mysqli_fetch_array($query);
                        } else {
                            echo "<script>alert('Data tidak ditemukan'); window.location.href = 'index.php?page=kategorii';</script>";
                            exit;
                        }
                    } else {
                        echo "<script>alert('ID tidak ditemukan.'); window.location.href = 'index.php?page=kategorii';</script>";
                        exit;
                    }
                    ?>

                    <div class="row mb-3">
                        <div class="col-md-2">Nama Kategori</div>
                        <div class="col-md-8">
                            <input type="text" class="form-control" value="<?php echo $data['NamaKategori']; ?>" name="kategoribuku">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                            <button type="reset" class="btn btn-primary">Reset</button>
                            <a href="index.php?page=kategorii" class="btn btn-danger">Kembali</a>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
